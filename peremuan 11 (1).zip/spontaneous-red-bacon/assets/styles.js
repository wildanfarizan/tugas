import { StyleSheet } from 'react-native';
const styles=StyleSheet.create({
    container:{
      flex:1,
      pading:20,
      margin:20,
      
    },
    teks:{
     marginTop:16,
     paddingvertical:8,
     borderWidth:2,
     borderRadius:8,
     backgroundColor:"lightgrey",
     color:"blue",
     textAlign:"center",
     fontSize:20,
     height:50,
     fontWeight:"bold"
    },
input:{
      paddingvertical:8,
      borderWidth:2,
      borderRadius:8,
      height:40,
      backgroundColor:"lightblue"
    
    },
    
});
export { styles }
